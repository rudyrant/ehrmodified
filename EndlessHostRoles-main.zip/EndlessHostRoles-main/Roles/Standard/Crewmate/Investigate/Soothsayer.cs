﻿using System.Collections.Generic;

namespace EHR.Roles;

public class Soothsayer : RoleBase
{
    public static bool On;
    private static List<Soothsayer> Instances;

    public static OptionItem CancelVote;

    private byte Target;
    public override bool IsEnable => On;

    public override void SetupCustomOption()
    {
        const int id = 649450;
        const TabGroup tab = TabGroup.CrewmateRoles;
        const CustomRoles role = CustomRoles.Soothsayer;

        Options.SetupRoleOptions(id, tab, role);
        CancelVote = Options.CreateVoteCancellingUseSetting(id + 2, role, tab);
    }

    public override void Init()
    {
        On = false;
        Instances = null;
    }

    public override void Add(byte playerId)
    {
        On = true;
        Instances ??= [];
        Instances.Add(this);
        Target = byte.MaxValue;
    }

    public override void Remove(byte playerId)
    {
        Instances?.Remove(this);
    }

    public override bool OnVote(PlayerControl voter, PlayerControl target)
    {
        return Options.UseJudgeAbilityAsTrigger.GetBool() || Options.UseMeetingShapeshift.GetBool() ? base.OnVote(voter, target) : OnJudge(voter, target);
    }

    public override bool OnJudge(PlayerControl player, PlayerControl target)
    {
        if (Starspawn.IsDayBreak) return false;
        if (player == null || target == null || player.PlayerId == target.PlayerId) return false;
        if (Target != byte.MaxValue || Main.DontCancelVoteList.Contains(player.PlayerId)) return false;

        Target = target.PlayerId;

        Main.DontCancelVoteList.Add(player.PlayerId);
        return true;
    }

    public override void OnMeetingShapeshift(PlayerControl shapeshifter, PlayerControl target)
    {
        OnJudge(shapeshifter, target);
    }

    public static void OnAnyoneDeath(PlayerControl killer)
    {
        if (!killer || Instances == null) return;
        Instances.DoIf(x => x.Target == killer.PlayerId, _ => Main.EnumerateAlivePlayerControls().Do(p => p.Notify(string.Format(Translator.GetString("SoothsayerDiedNotify"), Utils.ColorString(Main.PlayerColors.GetValueOrDefault(killer.PlayerId), killer.GetRealName())), 10f)));
    }
}