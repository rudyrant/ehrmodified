﻿using System.Collections.Generic;
using UnityEngine;

namespace EHR.Roles;

public class Dynamo : IAddon
{
    private static OptionItem MinSpeed;
    private static OptionItem Modulator;
    private static OptionItem MaxSpeed;
    private static OptionItem DisplaysCharge;

    private static Dictionary<byte, Vector2> LastPos;
    private static Dictionary<byte, int> LastNum;
    private static Dictionary<byte, long> LastUpdate;

    public AddonTypes Type => AddonTypes.Helpful;

    public void SetupCustomOption()
    {
        const int id = 19390;
        Options.SetupAdtRoleOptions(id, CustomRoles.Dynamo, canSetNum: true, teamSpawnOptions: true);

        MinSpeed = new FloatOptionItem(id + 10, "SpurtMinSpeed", new(0f, 3f, 0.25f), 1.25f, TabGroup.Addons)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dynamo])
            .SetValueFormat(OptionFormat.Multiplier);

        MaxSpeed = new FloatOptionItem(id + 11, "SpurtMaxSpeed", new(1.5f, 3f, 0.25f), 3f, TabGroup.Addons)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dynamo])
            .SetValueFormat(OptionFormat.Multiplier);

        Modulator = new FloatOptionItem(id + 8, "SpurtModule", new(0.25f, 3f, 0.25f), 1.25f, TabGroup.Addons)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dynamo])
            .SetValueFormat(OptionFormat.Multiplier);

        DisplaysCharge = new BooleanOptionItem(id + 9, "EnableSpurtCharge", true, TabGroup.Addons)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dynamo]);
    }

    public static void Add()
    {
        LastPos = null;
        LastNum = null;
        LastUpdate = null;
        
        foreach (PlayerControl pc in Main.CachedAlivePlayerControls())
        {
            if (pc.Is(CustomRoles.Dynamo))
            {
                LastPos ??= [];
                LastNum ??= [];
                LastUpdate ??= [];
                
                LastPos[pc.PlayerId] = pc.Pos();
                LastNum[pc.PlayerId] = 0;
                LastUpdate[pc.PlayerId] = Utils.TimeStamp;
            }
        }
    }

    public static string GetSuffix(PlayerControl player, bool hud = false)
    {
        if (!player.Is(CustomRoles.Dynamo) || !DisplaysCharge.GetBool() || GameStates.IsMeeting) return string.Empty;
        return $"<size={(hud ? 90 : 65)}%>{string.Format(Translator.GetString("DynamoSuffix"), DetermineCharge(player, out _, out _))}</size>";
    }

    public static void OnFixedUpdate(PlayerControl player)
    {
        if (LastPos == null) return;
        
        Vector2 pos = player.Pos();
        bool moving = !FastVector2.DistanceWithinRange(pos, LastPos[player.PlayerId], 0.1f) || player.MyPhysics.Animations.IsPlayingRunAnimation();
        LastPos[player.PlayerId] = pos;

        float modulator = Modulator.GetFloat();
        float increaseBy = Mathf.Clamp(modulator / 20 * 1.5f, 0.05f, 0.6f);

        int charge = DetermineCharge(player, out float minSpeed, out float maxSpeed);

        if (DisplaysCharge.GetBool() && !player.IsModdedClient() && LastNum[player.PlayerId] != charge)
        {
            LastNum[player.PlayerId] = charge;
            long now = Utils.TimeStamp;

            if (now != LastUpdate[player.PlayerId])
            {
                Utils.NotifyRoles(SpecifySeer: player, SpecifyTarget: player);
                LastUpdate[player.PlayerId] = now;
            }
        }

        if (!moving) Main.AllPlayerSpeed[player.PlayerId] = minSpeed;
        else Main.AllPlayerSpeed[player.PlayerId] += Mathf.Clamp(increaseBy, 0f, maxSpeed - Main.AllPlayerSpeed[player.PlayerId]);

        if (moving) player.MarkDirtySettings();
    }

    private static int DetermineCharge(PlayerControl player, out float minSpeed, out float maxSpeed)
    {
        minSpeed = MinSpeed.GetFloat();
        maxSpeed = MaxSpeed.GetFloat();
        return Mathf.Approximately(minSpeed, maxSpeed) ? 100 : (int)((Main.AllPlayerSpeed[player.PlayerId] - minSpeed) / (maxSpeed - minSpeed) * 100);
    }
}