﻿namespace EHR.Roles;

public class Evader : RoleBase
{
    public static bool On;

    public override bool IsEnable => On;

    public override void SetupCustomOption()
    {
        StartSetup(659800);
    }

    public override void Init()
    {
        On = false;
    }

    public override void Add(byte playerId)
    {
        On = true;
    }
}