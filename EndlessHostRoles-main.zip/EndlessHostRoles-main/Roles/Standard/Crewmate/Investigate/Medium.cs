﻿using System;
using System.Collections.Generic;
using static EHR.Translator;

namespace EHR.Roles;

public class Medium : RoleBase
{
    private const int Id = 7200;
    private static bool On;

    private static OptionItem ContactLimitOpt;
    public static OptionItem OnlyReceiveMsgFromCrew;
    public static OptionItem MediumAbilityUseGainWithEachTaskCompleted;
    public static OptionItem AbilityChargesWhenFinishedTasks;

    public static Dictionary<byte, byte> ContactPlayer;

    public override bool IsEnable => On;

    public override void SetupCustomOption()
    {
        Options.SetupRoleOptions(Id, TabGroup.CrewmateRoles, CustomRoles.Medium);

        ContactLimitOpt = new IntegerOptionItem(Id + 10, "MediumContactLimit", new(0, 15, 1), 1, TabGroup.CrewmateRoles)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Medium])
            .SetValueFormat(OptionFormat.Times);

        OnlyReceiveMsgFromCrew = new BooleanOptionItem(Id + 11, "MediumOnlyReceiveMsgFromCrew", true, TabGroup.CrewmateRoles)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Medium]);

        MediumAbilityUseGainWithEachTaskCompleted = new FloatOptionItem(Id + 12, "AbilityUseGainWithEachTaskCompleted", new(0f, 5f, 0.05f), 1f, TabGroup.CrewmateRoles)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Medium])
            .SetValueFormat(OptionFormat.Times);

        AbilityChargesWhenFinishedTasks = new FloatOptionItem(Id + 13, "AbilityChargesWhenFinishedTasks", new(0f, 5f, 0.05f), 0.2f, TabGroup.CrewmateRoles)
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Medium])
            .SetValueFormat(OptionFormat.Times);
    }

    public override void Init()
    {
        On = false;
        ContactPlayer = null;
    }

    public override void Add(byte playerId)
    {
        On = true;
        playerId.SetAbilityUseLimit(ContactLimitOpt.GetFloat());
    }

    public static void OnReportDeadBody(NetworkedPlayerInfo target)
    {
        ContactPlayer = [];
        if (target == null || !target.Object) return;

        foreach (PlayerControl pc in Main.CachedAlivePlayerControls())
        {
            if (!pc.Is(CustomRoles.Medium) || pc.PlayerId == target.PlayerId || pc.GetAbilityUseLimit() < 1) continue;

            pc.RpcRemoveAbilityUse(notify: false);
            ContactPlayer.TryAdd(target.PlayerId, pc.PlayerId);
            Logger.Info($"Medium Connection: {pc.GetNameWithRole()} => {target.PlayerName}", "Medium");
        }
    }

    public static bool MsMsg(PlayerControl pc, string msg)
    {
        if (!AmongUsClient.Instance.AmHost || !GameStates.IsMeeting || !pc || pc.IsAlive() || ContactPlayer == null || !ContactPlayer.TryGetValue(pc.PlayerId, out var contact) || (OnlyReceiveMsgFromCrew.GetBool() && !pc.IsCrewmate())) return false;

        msg = msg.ToLower().Trim();
        if (!CheckCommand(ref msg, "通灵|ms|medium", false)) return false;

        bool ans;

        if (msg.Contains('n') || msg.Contains(GetString("No"), StringComparison.OrdinalIgnoreCase) || msg.Contains('错') || msg.Contains("不是"))
            ans = false;
        else if (msg.Contains('y') || msg.Contains(GetString("Yes"), StringComparison.OrdinalIgnoreCase) || msg.Contains('对'))
            ans = true;
        else
        {
            Utils.SendMessage(GetString("MediumHelp"), pc.PlayerId);
            return true;
        }

        Utils.SendMessage(GetString("Medium" + (ans ? "Yes" : "No")), contact, CustomRoles.Medium.ColoredTextByRole(GetString("MediumTitle")), importance: MessageImportance.High);
        Utils.SendMessage(GetString("MediumDone"), pc.PlayerId, CustomRoles.Medium.ColoredTextByRole(GetString("MediumTitle")));

        ContactPlayer.Remove(pc.PlayerId);

        return true;
    }

    private static bool CheckCommand(ref string msg, string command, bool exact = true)
    {
        string[] comList = command.Split('|');

        foreach (string str in comList)
        {
            if (exact && msg == "/" + str) return true;

            if (msg.StartsWith("/" + str))
            {
                msg = msg.Replace("/" + str, string.Empty);
                return true;
            }
        }

        return false;
    }
}