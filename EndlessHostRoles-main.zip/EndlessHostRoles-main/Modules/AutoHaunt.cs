﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using AmongUs.GameOptions;
using EHR.Gamemodes;
using EHR.Roles;
using UnityEngine;

namespace EHR.Modules;

public static class AutoHaunt
{
    private static PlayerControl GetPreferredHauntTarget()
    {
        IEnumerable<PlayerControl> validPCs = Main.EnumerateAlivePlayerControls().Where(x => !AFKDetector.PlayerData.ContainsKey(x.PlayerId));

        return Options.CurrentGameMode switch
        {
            CustomGameMode.Standard => validPCs.OrderByDescending(x => x.GetCustomRole() is CustomRoles.Workaholic or CustomRoles.Snitch && x.GetTaskState().RemainingTasksCount <= 2).ThenByDescending(x => x.IsNeutralKiller()).ThenByDescending(x => x.IsImpostor()).ThenByDescending(x => x.Is(CustomRoleTypes.Coven)).ThenByDescending(x => x.GetCustomRole().IsNeutral()).FirstOrDefault(),
            CustomGameMode.SoloPVP => validPCs.Where(x => x.SoloAlive()).MinBy(x => SoloPVP.GetRankFromScore(x.PlayerId)),
            CustomGameMode.FFA => validPCs.MaxBy(x => FreeForAll.KillCount.GetValueOrDefault(x.PlayerId, 0)),
            CustomGameMode.StopAndGo => validPCs.MaxBy(x => x.GetTaskState().CompletedTasksCount),
            CustomGameMode.HotPotato => HotPotato.GetState().HolderID.GetPlayer(),
            CustomGameMode.HideAndSeek => validPCs.OrderByDescending(x => x.GetCustomRole() is CustomRoles.Venter or CustomRoles.Dasher or CustomRoles.Disguiser).ThenByDescending(x => CustomHnS.PlayerRoles.TryGetValue(x.PlayerId, out (IHideAndSeekRole Interface, CustomRoles Role) info) && info.Interface.Team == Team.Impostor).ThenByDescending(x => CustomHnS.PlayerRoles.TryGetValue(x.PlayerId, out (IHideAndSeekRole Interface, CustomRoles Role) info) && info.Interface.Team == Team.Neutral).FirstOrDefault(),
            CustomGameMode.Speedrun => Speedrun.CanKill.Count > 0 ? Speedrun.CanKill.ToValidPlayers().RandomElement() : validPCs.MaxBy(x => x.GetTaskState().CompletedTasksCount),
            CustomGameMode.CaptureTheFlag => validPCs.OrderByDescending(x => CaptureTheFlag.IsCarrier(x.PlayerId)).ThenByDescending(x => CaptureTheFlag.GetFlagTime(x.PlayerId)).ThenByDescending(x => CaptureTheFlag.GetTagCount(x.PlayerId)).FirstOrDefault(),
            CustomGameMode.RoomRush => RoomRush.PointsSystem ? validPCs.MaxBy(x => RoomRush.GetPoints(x.PlayerId)) : validPCs.RandomElement(),
            CustomGameMode.KingOfTheZones => validPCs.MaxBy(x => KingOfTheZones.GetZoneTime(x.PlayerId)),
            CustomGameMode.Deathrace => validPCs.MaxBy(x => Deathrace.Data.TryGetValue(x.PlayerId, out var drData) ? drData.Lap : 0),
            CustomGameMode.Snowdown => validPCs.Where(x => Snowdown.Data.ContainsKey(x.PlayerId)).Select(x => (pc: x, data: Snowdown.Data[x.PlayerId])).OrderByDescending(x => x.data.Points).ThenBy(x => x.data.SnowballGainInterval).ThenByDescending(x => x.data.Coins).ThenByDescending(x => x.data.SnowballsReady).Select(x => x.pc).FirstOrDefault(),
            _ => validPCs.RandomElement()
        };
    }

    public static void Start()
    {
        Main.Instance.StartCoroutine(AutoHauntCoroutine());
        return;

        IEnumerator AutoHauntCoroutine()
        {
            while (Main.AutoHaunt.Value)
            {
                float waitTime = 5f;
                
                if (HudManager.InstanceExists && GameStates.IsInTask && !ExileController.Instance && !AntiBlackout.SkipTasks && !PlayerControl.LocalPlayer.IsAlive() && PlayerControl.LocalPlayer.Data.RoleType is RoleTypes.CrewmateGhost or RoleTypes.ImpostorGhost && !ExtendedPlayerControl.TempExiled.Contains(PlayerControl.LocalPlayer.PlayerId) && !GhostRolesManager.AssignedGhostRoles.ContainsKey(PlayerControl.LocalPlayer.PlayerId))
                {
                    if (HauntMenuMinigameStartPatch.Instance)
                    {
                        PlayerControl currentTarget = HauntMenuMinigameStartPatch.Instance.HauntTarget;
                        PlayerControl preferredTarget = GetPreferredHauntTarget();

                        if (preferredTarget && currentTarget != preferredTarget)
                            HauntMenuMinigameSetHauntTargetPatch.Prefix(HauntMenuMinigameStartPatch.Instance, preferredTarget);

                        if (Options.CurrentGameMode == CustomGameMode.HotPotato)
                            waitTime = 0.5f;
                    }
                    else
                    {
                        HudManager.Instance.AbilityButton.DoClick();
                        waitTime = 1f;
                    }
                }

                yield return new WaitForSecondsRealtime(waitTime);
            }

            if (GameStates.IsInTask && !ExileController.Instance && !AntiBlackout.SkipTasks && !PlayerControl.LocalPlayer.IsAlive() && HauntMenuMinigameStartPatch.Instance)
                HauntMenuMinigameSetHauntTargetPatch.Prefix(HauntMenuMinigameStartPatch.Instance, null);
        }
    }
}