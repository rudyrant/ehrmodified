﻿using System.Collections.Generic;
using UnityEngine;
using static EHR.Options;

namespace EHR.Roles;

public class Mortician : RoleBase
{
    private const int Id = 7400;
    private static List<byte> PlayerIdList;

    private static OptionItem ShowArrows;

    private static Dictionary<byte, string> LastPlayerName;
    public static Dictionary<byte, string> MsgToSend;

    private byte MorticianId;

    public override bool IsEnable => PlayerIdList is { Count: > 0 };

    public override bool SeesArrowsToDeadBodies => ShowArrows.GetBool();

    public override void SetupCustomOption()
    {
        SetupRoleOptions(Id, TabGroup.CrewmateRoles, CustomRoles.Mortician);

        ShowArrows = new BooleanOptionItem(Id + 2, "ShowArrows", false, TabGroup.CrewmateRoles)
            .SetParent(CustomRoleSpawnChances[CustomRoles.Mortician]);
    }

    public override void Init()
    {
        PlayerIdList = null;
        LastPlayerName = null;
        MsgToSend = null;
    }

    public override void Add(byte playerId)
    {
        PlayerIdList ??= [];
        PlayerIdList.Add(playerId);
        MorticianId = playerId;
    }

    public override void Remove(byte playerId)
    {
        PlayerIdList?.Remove(playerId);
    }

    public static void OnPlayerDead(PlayerControl target)
    {
        LastPlayerName ??= [];
        LastPlayerName.TryAdd(target.PlayerId, FastVector2.TryGetClosestPlayerInRangeTo(target, 4f, out PlayerControl closest) ? closest.GetRealName() : string.Empty);
    }

    public static void OnReportDeadBody(PlayerControl pc, NetworkedPlayerInfo target)
    {
        if (PlayerIdList != null) foreach (byte apc in PlayerIdList) LocateArrow.RemoveAllTarget(apc);

        if (!pc.Is(CustomRoles.Mortician) || target == null || pc.PlayerId == target.PlayerId || LastPlayerName == null) return;

        LastPlayerName.TryGetValue(target.PlayerId, out string name);
        MsgToSend ??= [];
        MsgToSend.Add(pc.PlayerId, name == "" ? string.Format(Translator.GetString("MorticianGetNoInfo"), target.PlayerName) : string.Format(Translator.GetString("MorticianGetInfo"), target.PlayerName, name));
    }

    public override string GetSuffix(PlayerControl seer, PlayerControl target, bool hud = false, bool meeting = false)
    {
        if (ShowArrows.GetBool())
        {
            if (target != null && seer.PlayerId != target.PlayerId || seer.PlayerId != MorticianId || hud) return string.Empty;
            return meeting ? string.Empty : Utils.ColorString(Color.white, LocateArrow.GetArrows(seer));
        }

        return string.Empty;
    }
}