﻿using System.Collections.Generic;
using System.Linq;
using AmongUs.GameOptions;
using EHR.Modules.Extensions;

namespace EHR.Roles;

public class Siren : CovenBase
{
    public static bool On;
    private static List<Siren> Instances;

    private static OptionItem AbilityCooldown;
    private static OptionItem SingRange;
    private static OptionItem Stage1EffectsLength;
    private static OptionItem Stage2EffectsLength;
    private static OptionItem ReducedVision;
    private static OptionItem ReducedSpeed;
    public static OptionItem EntrancedCanKillCoven;
    public static OptionItem CovenKnowEntranced;
    public static OptionItem EntrancedKnowEntranced;
    public static OptionItem CovenCanKillEntranced;
    public static OptionItem EntrancedCountMode;
    public static OptionItem EntrancedKnowCoven;
    private static OptionItem CanVentBeforeNecronomicon;
    private static OptionItem CanVentAfterNecronomicon;

    private static readonly string[] CovenKnowEntrancedOptions =
    [
        "CKEO.SirenOnly",
        "CKEO.AllCoven"
    ];

    private static readonly string[] EntrancedCountModeOptions =
    [
        "ECMO.Nothing",
        "ECMO.Coven",
        "ECMO.OriginalTeam"
    ];

    private HashSet<byte> AffectedPlayers;
    private byte SirenId;

    private Dictionary<byte, int> Stages;

    protected override NecronomiconReceivePriorities NecronomiconReceivePriority => NecronomiconReceivePriorities.Random;

    public override bool IsEnable => On;

    public override void SetupCustomOption()
    {
        StartSetup(650130)
            .AutoSetupOption(ref AbilityCooldown, 30f, new FloatValueRule(0f, 120f, 0.5f), OptionFormat.Seconds)
            .AutoSetupOption(ref SingRange, 4f, new FloatValueRule(0.25f, 10f, 0.25f), OptionFormat.Multiplier)
            .AutoSetupOption(ref Stage1EffectsLength, 10, new IntegerValueRule(0, 60, 1), OptionFormat.Seconds)
            .AutoSetupOption(ref Stage2EffectsLength, 10, new IntegerValueRule(0, 60, 1), OptionFormat.Seconds)
            .AutoSetupOption(ref ReducedVision, 0.25f, new FloatValueRule(0f, 1f, 0.05f), OptionFormat.Multiplier)
            .AutoSetupOption(ref ReducedSpeed, 0.25f, new FloatValueRule(0f, 2f, 0.05f), OptionFormat.Multiplier)
            .AutoSetupOption(ref EntrancedCanKillCoven, false)
            .AutoSetupOption(ref CovenKnowEntranced, 1, CovenKnowEntrancedOptions)
            .AutoSetupOption(ref EntrancedKnowEntranced, false)
            .AutoSetupOption(ref CovenCanKillEntranced, true)
            .AutoSetupOption(ref EntrancedCountMode, 1, EntrancedCountModeOptions)
            .AutoSetupOption(ref EntrancedKnowCoven, 1, CovenKnowEntrancedOptions)
            .AutoSetupOption(ref CanVentBeforeNecronomicon, false)
            .AutoSetupOption(ref CanVentAfterNecronomicon, true);
    }

    public override void Init()
    {
        On = false;
        Instances = null;
    }

    public override void Add(byte playerId)
    {
        On = true;
        Stages = [];
        AffectedPlayers = [];
        SirenId = playerId;
        Instances ??= [];
        Instances.Add(this);
    }

    public override void Remove(byte playerId)
    {
        Instances?.Remove(this);
    }

    public override void ApplyGameOptions(IGameOptions opt, byte playerId)
    {
        AURoleOptions.PhantomCooldown = AbilityCooldown.GetFloat();
    }

    public static void ApplyGameOptionsForOthers(IGameOptions opt, byte playerId)
    {
        if (Instances == null) return;

        foreach (Siren instance in Instances)
        {
            if (instance.AffectedPlayers.Contains(playerId))
            {
                float vision = ReducedVision.GetFloat();
                opt.SetVision(false);
                opt.SetFloat(FloatOptionNames.CrewLightMod, vision);
                opt.SetFloat(FloatOptionNames.ImpostorLightMod, vision);
                Main.AllPlayerSpeed[playerId] = ReducedSpeed.GetFloat();
            }
        }
    }

    public override bool CanUseImpostorVentButton(PlayerControl pc)
    {
        return HasNecronomicon ? CanVentAfterNecronomicon.GetBool() : CanVentBeforeNecronomicon.GetBool();
    }

    public override bool CanUseKillButton(PlayerControl pc)
    {
        return HasNecronomicon;
    }

    public override bool OnVanish(PlayerControl pc)
    {
        PlayerControl[] nearbyPlayers = FastVector2.GetPlayersInRange(pc.Pos(), SingRange.GetFloat()).Without(pc).Where(x => !x.Is(Team.Coven)).ToArray();

        foreach (PlayerControl player in nearbyPlayers)
        {
            if (!Stages.ContainsKey(player.PlayerId))
                Stages[player.PlayerId] = HasNecronomicon ? 2 : 1;
            else
                Stages[player.PlayerId]++;

            switch (Stages[player.PlayerId])
            {
                case 1:
                    AffectedPlayers.Add(player.PlayerId);
                    _ = new CountdownTimer(Stage1EffectsLength.GetInt(), () =>
                    {
                        AffectedPlayers.Remove(player.PlayerId);
                        player.MarkDirtySettings();
                    }, onCanceled: () => AffectedPlayers.Remove(player.PlayerId));
                    player.MarkDirtySettings();
                    Utils.NotifyRoles(SpecifySeer: pc, SpecifyTarget: player);
                    break;
                case 2:
                    AffectedPlayers.Add(player.PlayerId);
                    _ = new CountdownTimer(Stage2EffectsLength.GetInt(), () =>
                    {
                        AffectedPlayers.Remove(player.PlayerId);
                        ReportDeadBodyPatch.CanReport[player.PlayerId] = true;
                        player.MarkDirtySettings();
                    }, onCanceled: () =>
                    {
                        AffectedPlayers.Remove(player.PlayerId);
                        ReportDeadBodyPatch.CanReport[player.PlayerId] = true;
                    });
                    ReportDeadBodyPatch.CanReport[player.PlayerId] = false;
                    player.MarkDirtySettings();
                    Utils.NotifyRoles(SpecifySeer: pc, SpecifyTarget: player);
                    break;
                case 3:
                    player.RpcSetCustomRole(CustomRoles.Entranced);
                    break;
            }
        }

        return false;
    }

    public override bool KnowRole(PlayerControl player, PlayerControl target)
    {
        if (base.KnowRole(player, target)) return true;
        if (player.Is(CustomRoles.Entranced) && (target.Is(CustomRoles.Siren) || (target.Is(CustomRoleTypes.Coven) && EntrancedKnowCoven.GetValue() == 1))) return true;
        return EntrancedKnowEntranced.GetBool() && player.Is(CustomRoles.Entranced) && target.Is(CustomRoles.Entranced);
    }

    public override string GetSuffix(PlayerControl seer, PlayerControl target, bool hud = false, bool meeting = false)
    {
        if (seer.PlayerId != SirenId || hud || seer.PlayerId == target.PlayerId) return string.Empty;
        return $"{Stages.GetValueOrDefault(target.PlayerId, 0)}/3";
    }
}