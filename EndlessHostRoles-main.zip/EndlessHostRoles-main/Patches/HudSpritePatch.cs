using System;
using System.Collections.Generic;
using AmongUs.GameOptions;
using EHR.Gamemodes;
using EHR.Modules;
using EHR.Patches;
using EHR.Roles;
using UnityEngine;

namespace EHR;

public static class CustomButton
{
    public static Sprite Get(string name)
    {
        return Utils.LoadSprite($"EHR.Resources.Images.Skills.{name}.png", 115f);
    }
}

//[HarmonyPriority(520)]
//[HarmonyPatch(typeof(HudManager), nameof(HudManager.Update))]
public static class HudSpritePatch
{
    public static bool ForceUpdate;
    public static Sprite[] DefaultIcons = [];
    private static long LastErrorTime;
    private static readonly List<CustomRoles> GhostRolesWithSprites = [CustomRoles.Bloodmoon, CustomRoles.Facilitator, CustomRoles.Minion, CustomRoles.MeetingAngel, CustomRoles.Warden, CustomRoles.Shade];

    public static void Postfix(HudManager __instance)
    {
        try
        {
            PlayerControl player = PlayerControl.LocalPlayer;
            if (!player) return;

            if (!Main.EnableCustomButton.Value || Mastermind.ManipulatedPlayers.ContainsKey(player.PlayerId) || ExileController.Instance) return;
            if (!SetHudActivePatch.IsActive && !MeetingStates.FirstMeeting) return;
            if (!AmongUsClient.Instance.IsGameStarted || !Main.IntroDestroyed || GameStates.IsLobby || GameStates.IsNotJoined || !GameStates.InGame || IntroCutsceneDestroyPatch.PreventKill) return;

            if (DefaultIcons.Length == 0) return;

            Sprite newKillButton = DefaultIcons[0];
            Sprite newAbilityButton = DefaultIcons[1];
            Sprite newVentButton = DefaultIcons[2];
            Sprite newSabotageButton = DefaultIcons[3];
            Sprite newPetButton = DefaultIcons[4];
            Sprite newReportButton = DefaultIcons[5];
            //Sprite newSecondaryAbilityButton = DefaultIcons[6];

            if (!player.IsAlive())
            {
                if (!GhostRolesManager.AssignedGhostRoles.TryGetValue(player.PlayerId, out (CustomRoles Role, IGhostRole Instance) ghostRole)) return;
                if (!GhostRolesWithSprites.Contains(ghostRole.Role)) return;

                newAbilityButton = CustomButton.Get(ghostRole.Role.ToString());
                goto Skip;
            }

            if (GameStates.IsMeeting)
            {
                if (player.UsesMeetingShapeshift())
                {
                    switch (player.GetCustomRole())
                    {
                        case CustomRoles.Starspawn:
                        {
                            newAbilityButton = CustomButton.Get("StarspawnShift");
                            break;
                        }
                        case CustomRoles.Loner:
                        {
                            newAbilityButton = CustomButton.Get("Sidekick");
                            break;
                        }
                        case CustomRoles.Exorcist: // temp
                        {
                            newAbilityButton = CustomButton.Get("Assassinate");
                            break;
                        }
                        case CustomRoles.Ventriloquist:
                        {
                            newAbilityButton = CustomButton.Get("Hack");
                            break;
                        }
                        case CustomRoles.Cleanser:
                        {
                            newAbilityButton = CustomButton.Get("Drink");
                            break;
                        }
                        case CustomRoles.Clerk: // temp
                        {
                            newAbilityButton = CustomButton.Get("Clerk");
                            break;
                        }
                        case CustomRoles.Godfather:
                        {
                            newAbilityButton = CustomButton.Get("EvilNearby");
                            break;
                        }
                        case CustomRoles.EvilEraser: // temp
                        case CustomRoles.NiceEraser:
                        {
                            newAbilityButton = CustomButton.Get("Erase");
                            break;
                        }
                        case CustomRoles.Councillor:
                        {
                            newAbilityButton = CustomButton.Get("Assassinate");
                            break;
                        }
                        case CustomRoles.Negotiator: // temp
                        {
                            newAbilityButton = CustomButton.Get("Attack");
                            break;
                        }
                        case CustomRoles.Swapper:
                        {
                            newAbilityButton = CustomButton.Get("PetToSwap");
                            break;
                        }
                        case CustomRoles.Tether:
                        {
                            newAbilityButton = CustomButton.Get("Track");
                            break;
                        }
                        case CustomRoles.Ricochet: // temp
                        {
                            newAbilityButton = CustomButton.Get("Shield");
                            break;
                        }
                        case CustomRoles.President:
                        case CustomRoles.Retributionist:
                        {
                            newAbilityButton = CustomButton.Get("Kill");
                            break;
                        }
                        case CustomRoles.Prosecutor:
                        {
                            newAbilityButton = CustomButton.Get("JudgeIcon");
                            break;
                        }
                        case CustomRoles.Socialite: // temp
                        {
                            newAbilityButton = CustomButton.Get("Bestower");
                            break;
                        }
                        case CustomRoles.Soothsayer:
                        case CustomRoles.Oracle:
                        case CustomRoles.Markseeker:
                        case CustomRoles.FortuneTeller:
                        {
                            newAbilityButton = CustomButton.Get("prophecies");
                            break;
                        }
                        case CustomRoles.Scout:
                        case CustomRoles.Captain:
                        {
                            newAbilityButton = CustomButton.Get("Track");
                            break;
                        }
                        case CustomRoles.Inspector:
                        case CustomRoles.Inquisitor: // temp
                        {
                            newAbilityButton = CustomButton.Get("InspectorIcon");
                            break;
                        }
                        case CustomRoles.Empress:
                        {
                            newAbilityButton = CustomButton.Get("Facilitator");
                            break;
                        }
                    }
                    goto Skip;
                }
                else return;
            }

            bool usesPetInsteadOfKill = player.UsesPetInsteadOfKill();
            bool shapeshifting = player.IsShifted();

            switch (player.GetCustomRole())
            {
                case CustomRoles.SnowdownPlayer:
                {   
                    if (Snowdown.Data.TryGetValue(player.PlayerId, out Snowdown.PlayerData snowdownData) && snowdownData.InShop) newAbilityButton = CustomButton.Get("PetToSwap");
                    else newAbilityButton = CustomButton.Get("Snowdown");
                    newKillButton = CustomButton.Get("Attack");
                    newPetButton = CustomButton.Get("Action");
                    newSabotageButton = CustomButton.Get("Shop");
                    break;
                }
                case CustomRoles.CTFPlayer:
                {
                    newAbilityButton = CustomButton.Get("Tag");
                    newKillButton = CustomButton.Get("Attack");
                    break;
                }
                case CustomRoles.Enderman:
                {
                    if (Options.UsePhantomBasis.GetBool()) newAbilityButton = CustomButton.Get("abscond");
                    else if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("abscond");
                    else newSabotageButton = CustomButton.Get("abscond");

                    break;
                }
                case CustomRoles.Dreamweaver:
                {
                    newKillButton = CustomButton.Get("Dreamweave");
                    break;
                }
                case CustomRoles.Wizard:
                {
                    newAbilityButton = CustomButton.Get("Up");
                    newPetButton = CustomButton.Get("PetToSwap");
                    newKillButton = CustomButton.Get("Wand");
                    break;
                }
                case CustomRoles.Tar:
                {
                    newPetButton = CustomButton.Get("Tar");
                    break;
                }
                case CustomRoles.Socialite:
                {
                    newKillButton = CustomButton.Get("Mark");
                    break;
                }
                case CustomRoles.Hitman:
                case CustomRoles.Augmenter:
                {
                    newAbilityButton = CustomButton.Get("Mark");
                    break;
                }
                case CustomRoles.Echo:
                {
                    newAbilityButton = player.IsShifted() ? newKillButton : CustomButton.Get("Puttpuer");
                    break;
                }
                case CustomRoles.Shifter:
                {
                    newKillButton = CustomButton.Get("PetToSwap");
                    break;
                }
                case CustomRoles.Changeling:
                {
                    newAbilityButton = CustomButton.Get("GlitchMimic");
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("PetToSwap");
                    else newVentButton = CustomButton.Get("PetToSwap");
                    break;
                }
                case CustomRoles.Silencer:
                case CustomRoles.Blackmailer:
                {
                    if (Silencer.SilenceMode.GetValue() >= 1 && player.Is(CustomRoles.Silencer)) newAbilityButton = CustomButton.Get("Blackmail");
                    else newKillButton = CustomButton.Get("Blackmail");
                    break;
                }
                case CustomRoles.Vulture:
                {
                    newReportButton = CustomButton.Get("Eat");
                    break;
                }
                case CustomRoles.Sentry:
                {
                    newPetButton = CustomButton.Get("Sentry");
                    break;
                }
                case CustomRoles.Commander:
                {
                    newAbilityButton = CustomButton.Get("Commander");
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("PetToSwap");
                    else newVentButton = CustomButton.Get("PetToSwap");
                    break;
                }
                case CustomRoles.Cleaner:
                {
                    newReportButton = CustomButton.Get("Clean");
                    break;
                }
                case CustomRoles.Addict:
                {
                    newAbilityButton = CustomButton.Get("Addict");
                    break;
                }
                case CustomRoles.Adventurer:
                {
                    newAbilityButton = CustomButton.Get("AdventurerCraft");
                    newPetButton = CustomButton.Get("PetToSwap");
                    break;
                }
                case CustomRoles.Occultist:
                case CustomRoles.Altruist:
                {
                    newReportButton = CustomButton.Get("Altruist");
                    break;
                }
                case CustomRoles.Bestower:
                {
                    newKillButton = CustomButton.Get("Bestower");
                    break;
                }
                case CustomRoles.CameraMan:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Camera Man");
                    else newAbilityButton = CustomButton.Get("Camera Man");
                    break;
                }
                case CustomRoles.Chameleon:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Chameleon");
                    else newAbilityButton = CustomButton.Get("Chameleon");
                    break;
                }
                case CustomRoles.Carrier:
                {
                    newAbilityButton = CustomButton.Get("TPToLoca");
                    newPetButton = CustomButton.Get("abscond");
                    break;
                }
                case CustomRoles.Astral:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Astral");
                    else newAbilityButton = CustomButton.Get("Astral");
                    break;
                }
                case CustomRoles.Catcher:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Catcher");
                    else newAbilityButton = CustomButton.Get("Catcher");
                    break;
                }
                case CustomRoles.Mole:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Mole");
                    else newAbilityButton = CustomButton.Get("Mole");
                    break;
                }
                case CustomRoles.PortalMaker:
                {
                    newPetButton = CustomButton.Get("PortalMaker");
                    break;
                }
                case CustomRoles.Tether:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("TPToLoca");
                    else newAbilityButton = CustomButton.Get("TPToLoca");
                    break;
                }
                case CustomRoles.Vacuum:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Vacuum");
                    else newAbilityButton = CustomButton.Get("Vacuum");
                    break;
                }
                case CustomRoles.Clairvoyant:
                case CustomRoles.Perceiver:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("EvilNearby");
                    else newAbilityButton = CustomButton.Get("EvilNearby");
                    break;
                }
                case CustomRoles.Coroner:
                {
                    newReportButton = CustomButton.Get("Coroner");
                    break;
                }
                case CustomRoles.Forensic:
                case CustomRoles.Mortician:
                {
                    newReportButton = CustomButton.Get("ExamineBody");
                    break;
                }
                case CustomRoles.Druid:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Druid");
                    else newAbilityButton = CustomButton.Get("Druid");
                    break;
                }
                case CustomRoles.Drainer:
                {
                    newAbilityButton = CustomButton.Get("Drainer");
                    break;
                }
                case CustomRoles.Whisperer:
                {
                    newPetButton = CustomButton.Get("Whisperer");
                    break;
                }
                case CustomRoles.Convener:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Convener");
                    else newAbilityButton = CustomButton.Get("Convener");
                    break;
                }
                case CustomRoles.Doorjammer:
                {
                    newPetButton = CustomButton.Get("Doorjammer");
                    break;
                }
                case CustomRoles.Farmer:
                {
                    newPetButton = CustomButton.Get("Farmer");
                    break;
                }
                case CustomRoles.Gardener:
                {
                    newPetButton = CustomButton.Get("Gardener");
                    break;
                }
                case CustomRoles.Tree:
                {
                    newPetButton = CustomButton.Get("Tree");
                    break;
                }
                case CustomRoles.Dad:
                {
                    newPetButton = CustomButton.Get("PetToSwap");
                    newAbilityButton = CustomButton.Get("Shop");
                    break;
                }
                case CustomRoles.Telekinetic:
                {
                    newAbilityButton = CustomButton.Get("PetToSwap");
                    newPetButton = CustomButton.Get("Action");
                    break;
                }
                case CustomRoles.Mechanic:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Mechanic");
                    break;
                }
                case CustomRoles.Monarch:
                case CustomRoles.Challenger:
                {
                    newKillButton = CustomButton.Get("Attack");
                    break;
                }
                case CustomRoles.BedWarsPlayer:
                {
                    newKillButton = CustomButton.Get("Attack");
                    newPetButton = CustomButton.Get("Action");
                    newAbilityButton = CustomButton.Get("PetToSwap");
                    break;
                }
                case CustomRoles.Crusader:
                {
                    newKillButton = CustomButton.Get("Crusader");
                    break;
                }
                case CustomRoles.Goose:
                {
                    newKillButton = CustomButton.Get("Drag");
                    break;
                }
                case CustomRoles.Oxyman:
                {
                    newAbilityButton = CustomButton.Get("Oxyman");
                    break;
                }
                case CustomRoles.Grenadier:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Grenadier");
                    else newAbilityButton = CustomButton.Get("Grenadier");
                    break;
                }
                //currently testing, may change later depending on how the role turns out
                case CustomRoles.Stealth:
                {
                    if (Stealth.UseLegacyVersion.GetBool()) newKillButton = CustomButton.Get("Grenadier");
                    else if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("Grenadier");
                    else if (!shapeshifting) newAbilityButton = CustomButton.Get("Grenadier");
                    break;
                }
                case CustomRoles.Sentinel:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Sentinel");
                    else newAbilityButton = CustomButton.Get("Sentinel");
                    break;
                }
                case CustomRoles.Tornado:
                {
                    newPetButton = CustomButton.Get("Tornado");
                    break;
                }
                case CustomRoles.ToiletMaster:
                {
                    newPetButton = CustomButton.Get("ToiLet");
                    break;
                }
                case CustomRoles.Rhapsode:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Rhapsode");
                    else newAbilityButton = CustomButton.Get("Rhapsode");
                    break;
                }
                case CustomRoles.Pacifist:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Pacifist");
                    else newAbilityButton = CustomButton.Get("Pacifist");
                    break;
                }
                case CustomRoles.Retributionist:
                {
                    newKillButton = CustomButton.Get("Ambusher");
                    break;
                }
                case CustomRoles.CopyCat:
                {
                    newKillButton = CustomButton.Get("Copycat");
                    break;
                }
                case CustomRoles.Scanner:
                {
                    newAbilityButton = CustomButton.Get("Scanner");
                    break;
                }
                case CustomRoles.Unshifter:
                {
                    newKillButton = CustomButton.Get("Fakeshift");
                    break;
                }
                case CustomRoles.Amnesiac:
                {
                    if (Amnesiac.RememberMode.GetValue() == 1) newKillButton = CustomButton.Get("AmnesiacKill");
                    else newReportButton = CustomButton.Get("AmnesiacReport");
                    break;
                }
                case CustomRoles.Ninja:
                case CustomRoles.Undertaker:
                {
                    if (Main.PlayerStates[player.PlayerId].Role is not Ninja ninja) break;

                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool())
                    {
                        newKillButton = CustomButton.Get("Mark");
                        if (ninja.MarkedPlayer != byte.MaxValue) newPetButton = CustomButton.Get("Assassinate");
                    }
                    else
                    {
                        if (!shapeshifting)
                        {
                            newKillButton = CustomButton.Get("Mark");
                            if (ninja.MarkedPlayer != byte.MaxValue) newAbilityButton = CustomButton.Get("Assassinate");
                        }
                    }

                    break;
                }
                case CustomRoles.Gaulois:
                {
                    newKillButton = CustomButton.Get("Gaulois");
                    break;
                }
                case CustomRoles.Consort:
                case CustomRoles.Escort:
                {
                    newKillButton = CustomButton.Get("GlitchHack");
                    break;
                }
                case CustomRoles.Glitch when Main.PlayerStates[player.PlayerId].Role is Glitch gc:
                {
                    if (gc.KCDTimer > 0 && gc.HackCDTimer <= 0) newKillButton = CustomButton.Get("GlitchHack");
                    newAbilityButton = CustomButton.Get("GlitchMimic");
                    break;
                }
                case CustomRoles.Jester:
                {
                    newAbilityButton = CustomButton.Get("JesterVent");
                    break;
                }
                case CustomRoles.Transporter when player.GetRoleTypes() == RoleTypes.Shapeshifter:
                case CustomRoles.Swapster:
                case CustomRoles.Transposer:
                {
                    newAbilityButton = CustomButton.Get("Transport");
                    break;
                }
                case CustomRoles.Disperser:
                {
                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("Disperse");
                    else if (!shapeshifting) newAbilityButton = CustomButton.Get("Disperse");

                    break;
                }
                case CustomRoles.Duellist:
                case CustomRoles.SoulCatcher:
                case CustomRoles.Twister:
                {
                    if (player.Is(CustomRoles.Twister) && Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("Transport");
                    else if (!shapeshifting) newAbilityButton = CustomButton.Get("Transport");

                    break;
                }
                case CustomRoles.Deputy:
                {
                    newKillButton = CustomButton.Get("Handcuff");
                    break;
                }
                case CustomRoles.Pursuer:
                {
                    newKillButton = CustomButton.Get("Pursuer");
                    break;
                }
                case CustomRoles.Alchemist:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Drink");
                    else newAbilityButton = CustomButton.Get("Drink");

                    break;
                }
                case CustomRoles.Jailor:
                {
                    newKillButton = CustomButton.Get("Jail");
                    break;
                }
                case CustomRoles.Penguin:
                {
                    newAbilityButton = CustomButton.Get("Timer");
                    newKillButton = CustomButton.Get("Drag");
                    break;
                }
                case CustomRoles.Revolutionist:
                {
                    newKillButton = CustomButton.Get("Tag");
                    newVentButton = CustomButton.Get("Tag");
                    break;
                }
                case CustomRoles.DonutDelivery:
                {
                    newKillButton = CustomButton.Get("Donut");
                    break;
                }
                case CustomRoles.Sapper:
                case CustomRoles.Bomber:
                case CustomRoles.Nuker:
                {
                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("Bomb");
                    else newAbilityButton = CustomButton.Get("Bomb");

                    break;
                }
                case CustomRoles.Camouflager:
                {
                    newAbilityButton = CustomButton.Get("Camo");
                    break;
                }
                case CustomRoles.Agitator:
                case CustomRoles.Potato:
                {
                    newKillButton = CustomButton.Get("bombshell");
                    break;
                }
                case CustomRoles.Arsonist:
                    {
                        newKillButton = CustomButton.Get("Douse");

                        if (Arsonist.ArsonistCanIgniteAnytime.GetBool() && Utils.GetDousedPlayerCount(player.PlayerId).Doused >= Arsonist.ArsonistMinPlayersToIgnite.GetInt() && HudManager.Instance.KillButton.currentTarget && player.IsDousedPlayer(HudManager.Instance.KillButton.currentTarget))
                            newKillButton = CustomButton.Get("Ignite");
                        else if (player.IsDouseDone() && Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Ignite");
                        else if (player.IsDouseDone()) newVentButton = CustomButton.Get("Ignite");
                        break;
                    }
                case CustomRoles.Pyromaniac:
                {
                    newKillButton = CustomButton.Get("Pyromaniac");
                    break;
                }
                case CustomRoles.Fireworker when Main.PlayerStates[player.PlayerId].Role is Fireworker fw:
                {
                    newAbilityButton = CustomButton.Get(fw.nowFireworksCount == 0 ? "FireworkD" : "FireworkP");
                    break;
                }
                case CustomRoles.Anonymous:
                {
                    newAbilityButton = CustomButton.Get("Hack");
                    break;
                }
                case CustomRoles.Hangman when shapeshifting:
                {
                    newAbilityButton = CustomButton.Get("Hangman");
                    break;
                }
                case CustomRoles.Paranoid:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Paranoid");
                    else newAbilityButton = CustomButton.Get("Paranoid");

                    break;
                }
                case CustomRoles.Mayor when Mayor.MayorHasPortableButton.GetBool():
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("EmergencyButton");
                    else newAbilityButton = CustomButton.Get("EmergencyButton");

                    break;
                }
                case CustomRoles.Puppeteer:
                {
                    newKillButton = CustomButton.Get("Puttpuer");
                    break;
                }
                case CustomRoles.Aid:
                case CustomRoles.Medic:
                {
                    newKillButton = CustomButton.Get("Shield");
                    break;
                }
                case CustomRoles.Survivor:
                {
                    newAbilityButton = CustomButton.Get("Shield");
                    break;
                }
                case CustomRoles.Gangster when Gangster.CanRecruit(player.PlayerId):
                case CustomRoles.Jackal when player.GetAbilityUseLimit() > 0:
                {
                    newKillButton = CustomButton.Get("Sidekick");
                    break;
                }
                case CustomRoles.Cultist:
                {
                    newKillButton = CustomButton.Get("Subbus");
                    break;
                }
                case CustomRoles.Innocent:
                {
                    newKillButton = CustomButton.Get("Suidce");
                    break;
                }
                case CustomRoles.EvilTracker:
                {
                    newAbilityButton = CustomButton.Get("Track");
                    break;
                }
                case CustomRoles.Vampire:
                {
                    newKillButton = CustomButton.Get("Bite");
                    break;
                }
                case CustomRoles.Veteran:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Veteran");
                    else newAbilityButton = CustomButton.Get("Veteran");

                    break;
                }
                case CustomRoles.Lighter:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("Lighter");
                    else newAbilityButton = CustomButton.Get("Lighter");

                    break;
                }
                case CustomRoles.SecurityGuard:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("BlockSabo");
                    else newAbilityButton = CustomButton.Get("BlockSabo");

                    break;
                }
                case CustomRoles.Ventguard:
                {
                    newAbilityButton = CustomButton.Get("Block");
                    break;
                }
                case CustomRoles.Romantic:
                {
                    newKillButton = CustomButton.Get(!Romantic.HasPickedPartner ? "Romance" : "RomanticProtect");
                    break;
                }
                case CustomRoles.VengefulRomantic:
                {
                    newKillButton = CustomButton.Get("RomanticKill");
                    break;
                }
                case CustomRoles.Miner:
                {
                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("Mine");
                    else newAbilityButton = CustomButton.Get("Mine");
                    break;
                }
                case CustomRoles.Wiper:
                {
                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = DefaultIcons[0];
                    else newAbilityButton = DefaultIcons[0];
                    break;
                }
                case CustomRoles.Analyst:
                case CustomRoles.Witness:
                {
                    newKillButton = CustomButton.Get("Examine");
                    break;
                }
                case CustomRoles.Postman:
                {
                    newKillButton = CustomButton.Get("Deliver");
                    break;
                }
                case CustomRoles.Pelican:
                {
                    newKillButton = CustomButton.Get("Vulture");
                    break;
                }
                case CustomRoles.TimeMaster:
                {
                    if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("TimeMaster");
                    else newAbilityButton = CustomButton.Get("TimeMaster");

                    break;
                }
                case CustomRoles.Sheriff:
                {
                    newKillButton = CustomButton.Get("Kill");
                    break;
                }
                case CustomRoles.Dasher:
                case CustomRoles.Swiftclaw:
                {
                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("Dash");
                    else newAbilityButton = CustomButton.Get("Dash");

                    break;
                }
                case CustomRoles.Swooper:
                case CustomRoles.Wraith:
                {
                    if (Options.UsePhantomBasis.GetBool()) newAbilityButton = CustomButton.Get("invisible");
                    else if (Options.UsePets.GetBool()) newPetButton = CustomButton.Get("invisible");
                    else newVentButton = CustomButton.Get("invisible");
                    break;
                }
                case CustomRoles.Visionary:
                {
                    newAbilityButton = CustomButton.Get("prophecies");
                    break;
                }
                case CustomRoles.Perplexer:
                {
                    newAbilityButton = CustomButton.Get("Perplexer");
                    break;
                }
                case CustomRoles.Escapist:
                {
                    if (Options.UsePets.GetBool() && !Options.UsePhantomBasis.GetBool()) newPetButton = CustomButton.Get("abscond");
                    else newAbilityButton = CustomButton.Get("abscond");

                    break;
                }
                case CustomRoles.Tunneler:
                {
                    newPetButton = CustomButton.Get("abscond");
                    break;
                }
                case CustomRoles.Investigator:
                {
                    newKillButton = CustomButton.Get("prophecies");
                    break;
                }
                case CustomRoles.Warlock:
                {
                    if (Options.UsePets.GetBool() || !shapeshifting)
                    {
                        newKillButton = CustomButton.Get("Curse");
                        if (Warlock.IsCurseAndKill.TryGetValue(player.PlayerId, out bool curse) && curse)
                            newAbilityButton = CustomButton.Get("CurseKill");
                    }

                    break;
                }
                default:
                {
                    if (player.Is(CustomRoles.Sleuth) || player.Is(CustomRoles.Bloodlust) || ForceUpdate || usesPetInsteadOfKill) break;
                    SetButtonColors();
                    return;
                }
            }

            if (usesPetInsteadOfKill)
                newPetButton = newKillButton;

            // shows default pet button if the ability can't be used yet due to cooldowns or if they no longer have uses left
            if (!Options.UsePets.GetBool() || player.HasAbilityCD() || player.GetAbilityUseLimit() < 1) // conditions with float.NaN always evaluate to false, which is good in this case
                newPetButton = DefaultIcons[4];

            // for Bloodlust, due to it using the impostor vent button instead of the engineer vent button, show it on the vent button instead of the ability button, and only if the ability button is not the default button
            if (player.Is(CustomRoles.Bloodlust) && newAbilityButton != DefaultIcons[1] && !player.Is(CustomRoles.Scanner) && !player.Is(CustomRoles.Transporter))
                newVentButton = newAbilityButton;

            if (player.Is(CustomRoles.Sleuth) && newReportButton == DefaultIcons[5])
                newReportButton = CustomButton.Get("ExamineBody");

            Skip:

            SetButtonColors();

            __instance.KillButton.graphic.sprite = newKillButton;
            __instance.AbilityButton.graphic.sprite = newAbilityButton;
            __instance.ImpostorVentButton.graphic.sprite = newVentButton;
            __instance.SabotageButton.graphic.sprite = newSabotageButton;
            __instance.PetButton.graphic.sprite = newPetButton;
            __instance.ReportButton.graphic.sprite = newReportButton;

            __instance.KillButton.graphic.SetCooldownNormalizedUvs();
            __instance.AbilityButton.graphic.SetCooldownNormalizedUvs();
            __instance.ImpostorVentButton.graphic.SetCooldownNormalizedUvs();
            __instance.SabotageButton.graphic.SetCooldownNormalizedUvs();
            __instance.PetButton.graphic.SetCooldownNormalizedUvs();
            __instance.ReportButton.graphic.SetCooldownNormalizedUvs();
            __instance.SecondaryAbilityButton.graphic.SetCooldownNormalizedUvs();
            
            ForceUpdate = false;

            void SetButtonColors()
            {
                var roleColor = Utils.GetRoleColor(player.GetCustomRole());

                foreach (var button in new ActionButton[] { __instance.KillButton, __instance.AbilityButton, __instance.ImpostorVentButton, __instance.SabotageButton, __instance.PetButton, __instance.ReportButton, __instance.SecondaryAbilityButton })
                    button.buttonLabelText.SetOutlineColor(roleColor);
            }
        }
        catch (Exception e)
        {
            if (Utils.TimeStamp - LastErrorTime > 10)
            {
                LastErrorTime = Utils.TimeStamp;
                Utils.ThrowException(e);
            }
        }
    }
}
