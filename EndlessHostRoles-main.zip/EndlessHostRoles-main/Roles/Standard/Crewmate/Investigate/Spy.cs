using System.Collections.Generic;
using EHR.Modules;
using EHR.Modules.Extensions;
using Hazel;

namespace EHR.Roles;

using static Options;
using static Utils;

public class Spy : RoleBase
{
    private const int Id = 640400;
    private static bool On;
    public static HashSet<byte> SpyRedNameList;

    private static OptionItem SpyRedNameDur;
    private static OptionItem UseLimitOpt;
    public static OptionItem SpyAbilityUseGainWithEachTaskCompleted;
    public static OptionItem AbilityChargesWhenFinishedTasks;

    public override bool IsEnable => On;

    public override void SetupCustomOption()
    {
        SetupRoleOptions(Id, TabGroup.CrewmateRoles, CustomRoles.Spy);

        UseLimitOpt = new IntegerOptionItem(Id + 10, "AbilityUseLimit", new(0, 20, 1), 1, TabGroup.CrewmateRoles)
            .SetParent(CustomRoleSpawnChances[CustomRoles.Spy])
            .SetValueFormat(OptionFormat.Times);

        SpyRedNameDur = new FloatOptionItem(Id + 11, "SpyRedNameDur", new(0f, 70f, 0.5f), 3f, TabGroup.CrewmateRoles)
            .SetParent(CustomRoleSpawnChances[CustomRoles.Spy])
            .SetValueFormat(OptionFormat.Seconds);

        SpyAbilityUseGainWithEachTaskCompleted = new FloatOptionItem(Id + 12, "AbilityUseGainWithEachTaskCompleted", new(0f, 5f, 0.05f), 0.5f, TabGroup.CrewmateRoles)
            .SetParent(CustomRoleSpawnChances[CustomRoles.Spy])
            .SetValueFormat(OptionFormat.Times);

        AbilityChargesWhenFinishedTasks = new FloatOptionItem(Id + 13, "AbilityChargesWhenFinishedTasks", new(0f, 5f, 0.05f), 0.2f, TabGroup.CrewmateRoles)
            .SetParent(CustomRoleSpawnChances[CustomRoles.Spy])
            .SetValueFormat(OptionFormat.Times);
    }

    public override void Init()
    {
        On = false;
        SpyRedNameList = null;
    }

    public override void Add(byte playerId)
    {
        On = true;
        playerId.SetAbilityUseLimit(UseLimitOpt.GetFloat());
    }

    private static void SendRPC(int operate, byte id = byte.MaxValue)
    {
        if (!DoRPC) return;

        MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SyncSpy, SendOption.Reliable);
        writer.Write(operate);
        writer.Write(id);
        AmongUsClient.Instance.FinishRpcImmediately(writer);
    }

    public static void ReceiveRPC(MessageReader reader)
    {
        int operate = reader.ReadInt32();

        switch (operate)
        {
            case 1:
                byte susId = reader.ReadByte();
                SpyRedNameList ??= [];
                SpyRedNameList.Add(susId);
                return;
            case 3:
                SpyRedNameList?.Remove(reader.ReadByte());
                return;
        }
    }

    public static bool OnKillAttempt(PlayerControl killer, PlayerControl target) // Special handling for Spy ---- remains as a static method
    {
        if (!target.Is(CustomRoles.Spy) || killer.PlayerId == target.PlayerId || target.GetAbilityUseLimit() < 1) return true;

        target.RpcRemoveAbilityUse(notify: false);
        SpyRedNameList ??= [];
        SpyRedNameList.Add(killer.PlayerId);
        SendRPC(1, killer.PlayerId);
        NotifyRoles(SpecifySeer: target, SpecifyTarget: killer);
        killer.SetKillCooldown();

        _ = new CountdownTimer(SpyRedNameDur.GetInt(), () =>
        {
            SpyRedNameList?.Remove(killer.PlayerId);
            SendRPC(3, killer.PlayerId);
            NotifyRoles(SpecifySeer: target, SpecifyTarget: killer);
        }, onCanceled: () =>
        {
            SpyRedNameList?.Remove(killer.PlayerId);
            SendRPC(3, killer.PlayerId);
        });
        return false;
    }
}
