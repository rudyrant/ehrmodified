﻿using System;
using System.Collections.Generic;
using AmongUs.GameOptions;
using EHR.Modules.Extensions;

namespace EHR.Roles;

public class Farmer : RoleBase
{
    public static bool On;
    private static List<Farmer> Instances = [];

    public override bool IsEnable => On;

    private List<Seed> Seeds;
    private List<(Seed Seed, EHR.Seed NetObject)> SeedPositions;
    private Dictionary<Seed, CountdownTimer> ActiveSeeds;
    private byte FarmerId;

    private static readonly StringBuilder Suffix = new();
    private static readonly Seed[] AllSeed = Enum.GetValues<Seed>();

    private static OptionItem HarvestRange;
    private static OptionItem IncreasedVision;
    private static OptionItem IncreasedVisionDuration;
    private static OptionItem IncreasedSpeed;
    private static OptionItem IncreasedSpeedDuration;
    private static OptionItem ShieldDuration;
    private static OptionItem InvisibilityDuration;

    public override void SetupCustomOption()
    {
        StartSetup(654000)
            .AutoSetupOption(ref HarvestRange, 1.5f, new FloatValueRule(0.25f, 5f, 0.25f), OptionFormat.Multiplier)
            .AutoSetupOption(ref IncreasedVision, 1f, new FloatValueRule(0.1f, 2f, 0.1f), OptionFormat.Multiplier)
            .AutoSetupOption(ref IncreasedVisionDuration, 15, new IntegerValueRule(1, 60, 1), OptionFormat.Seconds)
            .AutoSetupOption(ref IncreasedSpeed, 2f, new FloatValueRule(0.25f, 3f, 0.25f), OptionFormat.Multiplier)
            .AutoSetupOption(ref IncreasedSpeedDuration, 30, new IntegerValueRule(1, 60, 1), OptionFormat.Seconds)
            .AutoSetupOption(ref ShieldDuration, 15, new IntegerValueRule(1, 60, 1), OptionFormat.Seconds)
            .AutoSetupOption(ref InvisibilityDuration, 30, new IntegerValueRule(1, 60, 1), OptionFormat.Seconds);
    }

    public override void Init()
    {
        On = false;
        Instances = [];
    }

    public override void Add(byte playerId)
    {
        On = true;
        Seeds = [];
        SeedPositions = [];
        ActiveSeeds = [];
        FarmerId = playerId;
        Instances.Add(this);
    }

    public override void Remove(byte playerId)
    {
        Instances.Remove(this);
    }

    public override void OnTaskComplete(PlayerControl pc, int completedTaskCount, int totalTaskCount)
    {
        Seeds.Add(AllSeed.RandomElement());
    }

    public override void OnPet(PlayerControl pc)
    {
        Vector2 pos = pc.Pos();
        float range = HarvestRange.GetFloat();

        if (SeedPositions.FindFirst(x => x.NetObject.Spawned && !FastVector2.DistanceWithinRange(pos, x.NetObject.Position, range), out var existing))
        {
            switch (existing.Seed)
            {
                case Seed.Wheat:
                    Utils.MarkEveryoneDirtySettings();
                    goto default;
                case Seed.Apple:
                    pc.RpcMakeInvisible();
                    goto default;
                case Seed.Tomato:
                    Main.AllPlayerSpeed[pc.PlayerId] = IncreasedSpeed.GetFloat();
                    pc.MarkDirtySettings();
                    goto default;
                case Seed.Potato:
                    Main.EnumerateAlivePlayerControls().DoIf(x => !x.Is(Team.Crewmate), x => x.SetKillCooldown(Main.AllPlayerKillCooldown.GetValueOrDefault(x.PlayerId, -1f)));
                    break;
                case Seed.Blueberry:
                    Object.FindObjectsOfType<DeadBody>().Do(x => LocateArrow.Add(pc.PlayerId, x.TruePosition));
                    Utils.NotifyRoles(SpecifySeer: pc, SpecifyTarget: pc);
                    break;
                default:
                    ActiveSeeds[existing.Seed] = new CountdownTimer(existing.Seed switch
                    {
                        Seed.Wheat => IncreasedVisionDuration.GetInt(),
                        Seed.Carrot => ShieldDuration.GetInt(),
                        Seed.Apple => InvisibilityDuration.GetInt(),
                        Seed.Tomato => IncreasedSpeedDuration.GetInt(),
                        _ => 0
                    }, () =>
                    {
                        ActiveSeeds.Remove(existing.Seed);

                        switch (existing.Seed)
                        {
                            case Seed.Wheat:
                                Utils.MarkEveryoneDirtySettings();
                                break;
                            case Seed.Apple:
                                pc.RpcMakeVisible();
                                break;
                            case Seed.Tomato:
                                Main.AllPlayerSpeed[pc.PlayerId] = Main.RealOptionsData.GetFloat(FloatOptionNames.PlayerSpeedMod);
                                pc.MarkDirtySettings();
                                break;
                        }
                    }, onCanceled: () =>
                    {
                        ActiveSeeds.Remove(existing.Seed);
                        if (existing.Seed != Seed.Tomato || Main.RealOptionsData == null) return;
                        Main.AllPlayerSpeed[pc.PlayerId] = Main.RealOptionsData.GetFloat(FloatOptionNames.PlayerSpeedMod);
                    });
                    break;
            }
            
            existing.NetObject.Despawn();
            SeedPositions.Remove(existing);
            return;
        }
        
        if (Seeds.Count == 0) return;
        Seed seed = Seeds[0];
        SeedPositions.Add((seed, new(pos, GetHexColor(seed))));
        Seeds.RemoveAt(0);
        Utils.NotifyRoles(SpecifySeer: pc, SpecifyTarget: pc);
    }

    private static string GetHexColor(Seed s) => s switch
    {
        Seed.Wheat => "FFFF00",
        Seed.Carrot => "FFA500",
        Seed.Apple => "FF0000",
        Seed.Tomato => "FF6347",
        Seed.Potato => "D2B48C",
        Seed.Blueberry => "0000FF",
        _ => "FFFFFF"
    };

    public override void AfterMeetingTasks()
    {
        SeedPositions.ForEach(x => x.NetObject.SpawnIfNotSpawned());
    }

    public override void OnReportDeadBody()
    {
        LocateArrow.RemoveAllTarget(FarmerId);
    }

    public static void OnAnyoneApplyGameOptions(IGameOptions opt, PlayerControl player)
    {
        if (On && player.Is(Team.Crewmate) && Instances.Exists(x => x.ActiveSeeds.ContainsKey(Seed.Wheat)))
        {
            opt.SetFloat(FloatOptionNames.CrewLightMod, IncreasedVision.GetFloat());
            opt.SetFloat(FloatOptionNames.ImpostorLightMod, IncreasedVision.GetFloat());
        }
    }

    public static bool OnAnyoneCheckMurder(PlayerControl target)
    {
        return !On || !target.Is(Team.Crewmate) || !Instances.Exists(x => x.ActiveSeeds.ContainsKey(Seed.Carrot));
    }

    enum Seed
    {
        Wheat, // Increased vision for all crewmates
        Carrot, // Shield for all crewmates
        Apple, // Invisibility (self only)
        Tomato, // Speed boost (self only)
        Potato, // Reset all killers' cooldowns
        Blueberry // Arrow to all dead bodies
    }

    public override string GetSuffix(PlayerControl seer, PlayerControl target, bool hud = false, bool meeting = false)
    {
        if (seer.PlayerId != FarmerId || seer.PlayerId != target.PlayerId || (seer.IsModdedClient() && !hud) || meeting) return string.Empty;

        Suffix.Clear();
        if (Seeds.Count > 0) Suffix.AppendFormat(Translator.GetString("Farmer.SelectedSeed"), Utils.GetRoleColorCode(CustomRoles.Farmer), $"<#{GetHexColor(Seeds[0])}>{Translator.GetString($"Farmer.Seed.{Seeds[0]}")}</color>").AppendLine();
        else Suffix.AppendFormat(Translator.GetString("Farmer.CompleteTaskToGetSeed"), Utils.GetRoleColorCode(CustomRoles.Farmer)).AppendLine();
        if (Seeds.Count > 1) Suffix.AppendFormat(Translator.GetString("Farmer.MoreSeeds"), Seeds.Count - 1).AppendLine();
        Suffix.Append(LocateArrow.GetArrows(seer));
        return Suffix.ToString().Trim();
    }
}