﻿using AmongUs.GameOptions;
using EHR.Gamemodes;
using EHR.Modules.Extensions;

namespace EHR.Roles;

public class Dasher : RoleBase, IHideAndSeekRole
{
    public static bool On;

    private static OptionItem DashCooldown;
    private static OptionItem DashDuration;
    private static OptionItem DashSpeed;
    private static OptionItem UseLimit;
    private static OptionItem Vision;
    private static OptionItem Speed;

    private DashStatus DashStatus;

    public override bool IsEnable => On;
    public Team Team => Team.Impostor;
    public int Chance => CustomRoles.Dasher.GetMode();
    public int Count => CustomRoles.Dasher.GetCount();
    public float RoleSpeed => Speed.GetFloat();
    public float RoleVision => Vision.GetFloat();

    public override void SetupCustomOption()
    {
        Options.SetupRoleOptions(69_211_801, TabGroup.ImpostorRoles, CustomRoles.Dasher, CustomGameMode.HideAndSeek);

        Vision = new FloatOptionItem(69_211_803, "DasherVision", new(0.05f, 5f, 0.05f), 0.25f, TabGroup.ImpostorRoles)
            .SetGameMode(CustomGameMode.HideAndSeek)
            .SetValueFormat(OptionFormat.Multiplier)
            .SetColor(new(245, 66, 176, byte.MaxValue))
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dasher]);

        Speed = new FloatOptionItem(69_213_804, "DasherSpeed", new(0.05f, 5f, 0.05f), 1.5f, TabGroup.ImpostorRoles)
            .SetGameMode(CustomGameMode.HideAndSeek)
            .SetValueFormat(OptionFormat.Multiplier)
            .SetColor(new(245, 66, 176, byte.MaxValue))
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dasher]);

        DashCooldown = new FloatOptionItem(69_213_805, "DasherCooldown", new(0f, 60f, 0.5f), 20f, TabGroup.ImpostorRoles)
            .SetGameMode(CustomGameMode.HideAndSeek)
            .SetValueFormat(OptionFormat.Seconds)
            .SetColor(new(245, 66, 176, byte.MaxValue))
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dasher]);

        DashDuration = new FloatOptionItem(69_213_806, "DasherDuration", new(1f, 30f, 1f), 5f, TabGroup.ImpostorRoles)
            .SetGameMode(CustomGameMode.HideAndSeek)
            .SetValueFormat(OptionFormat.Seconds)
            .SetColor(new(245, 66, 176, byte.MaxValue))
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dasher]);

        DashSpeed = new FloatOptionItem(69_213_807, "DasherSpeedIncreased", new(0.05f, 5f, 0.05f), 1.5f, TabGroup.ImpostorRoles)
            .SetGameMode(CustomGameMode.HideAndSeek)
            .SetValueFormat(OptionFormat.Multiplier)
            .SetColor(new(245, 66, 176, byte.MaxValue))
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dasher]);

        UseLimit = new FloatOptionItem(69_213_808, "AbilityUseLimit", new(0, 20, 0.05f), 3, TabGroup.ImpostorRoles)
            .SetGameMode(CustomGameMode.HideAndSeek)
            .SetColor(new(245, 66, 176, byte.MaxValue))
            .SetParent(Options.CustomRoleSpawnChances[CustomRoles.Dasher]);
    }

    public override void Add(byte playerId)
    {
        On = true;
        playerId.SetAbilityUseLimit(UseLimit.GetFloat());

        DashStatus = new()
        {
            Cooldown = DashCooldown.GetInt(),
            Duration = DashDuration.GetInt()
        };
    }

    public override void Init()
    {
        On = false;
    }

    public override bool CanUseImpostorVentButton(PlayerControl pc)
    {
        return false;
    }

    public override void ApplyGameOptions(IGameOptions opt, byte playerId)
    {
        Main.AllPlayerSpeed[playerId] = DashStatus.IsDashing ? DashSpeed.GetFloat() : CustomHnS.IsBlindTime ? Main.MinSpeed : RoleSpeed;

        if (Options.UsePhantomBasis.GetBool())
        {
            AURoleOptions.PhantomCooldown = DashStatus.Cooldown + DashStatus.Duration;
            AURoleOptions.PhantomDuration = 0.1f;
        }
    }

    public override bool OnVanish(PlayerControl pc)
    {
        Dash(pc);
        return false;
    }

    public override void OnPet(PlayerControl pc)
    {
        if (pc.HasAbilityCD()) return;
        Dash(pc);
        pc.AddAbilityCD(DashStatus.Cooldown + DashStatus.Duration);
    }

    private void Dash(PlayerControl pc)
    {
        if (DashStatus.IsDashing || pc.GetAbilityUseLimit() < 1f) return;

        DashStatus.IsDashing = true;
        _ = new CountdownTimer(DashStatus.Duration, () =>
        {
            DashStatus.IsDashing = false;
            pc.MarkDirtySettings();
        });
        pc.MarkDirtySettings();
        pc.RpcRemoveAbilityUse();
    }

    public override void SetButtonTexts(HudManager hud, byte id)
    {
        if (!Options.UsePhantomBasis.GetBool())
            hud.PetButton?.OverrideText(Translator.GetString("SwiftclawAbilityButtonText"));
        else
            hud.AbilityButton?.OverrideText(Translator.GetString("SwiftclawAbilityButtonText"));
    }
}
